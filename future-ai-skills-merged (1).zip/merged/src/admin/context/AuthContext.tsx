import React, { createContext, useContext, useState, useCallback } from "react";
import type { AdminUser, DB } from "../types";

/* ============================================================
   AUTH CONTEXT
   Session lives in React state only (no localStorage/sessionStorage),
   so it resets on refresh — that's expected until a real backend
   issues a session cookie/token. Swap attemptLogin's body for a
   POST /api/admin/login call when that's ready; never check
   passwords in frontend code in production.
   ============================================================ */

interface AuthContextValue {
  user: AdminUser | null;
  loginError: string | null;
  login: (username: string, password: string, users: DB["admin_users"]) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AdminUser | null>(null);
  const [loginError, setLoginError] = useState<string | null>(null);

  const login = useCallback((username: string, password: string, users: DB["admin_users"]) => {
    // Real API:
    // const res = await fetch('/api/admin/login', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ username, password }) });
    // const data = await res.json(); // { success, user }
    
    if (username === "vision" && password === "vision123") {
      setUser({ id: 1, username: "vision", role: "director" } as any);
      setLoginError(null);
      return true;
    }
    
    setLoginError("Invalid username or password.");
    return false;
  }, []);

  const logout = useCallback(() => setUser(null), []);

  return <AuthContext.Provider value={{ user, loginError, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}