import React, { useState } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { ToastProvider } from "./context/ToastContext";
import { ENTITIES } from "./config/entities";
import type { ManagedTable } from "./types";
import LoginPage from "./pages/LoginPage";
import Overview from "./pages/Overview";
import Sidebar from "./components/Sidebar";
import Topbar from "./components/Topbar";
import EntitySection from "./components/EntitySection";
import "./index.css";

/* ============================================================
   ADMIN APP ENTRY POINT
   Mounted at /admin/* by the main site's router (see src/App.jsx).
   DataProvider is NOT wrapped here — it lives once at the app
   root (src/main.jsx) so the admin panel and the public site
   share the exact same live data instead of two disconnected copies.
   Everything below is wrapped in the "admin-scope" class so the
   admin panel's stylesheet (index.css) never bleeds into the
   public site's styles, and vice versa.
   ============================================================ */

type Section = "overview" | ManagedTable;

function AdminShell() {
  const { user } = useAuth();
  const [section, setSection] = useState<Section>("overview");
  const [menuOpen, setMenuOpen] = useState(false);

  if (!user) {
    return <LoginPage />;
  }

  const title = section === "overview" ? "Overview" : ENTITIES[section].label;
  const subtitle = section === "overview" ? "Everything on your site, in one place." : ENTITIES[section].description;

  return (
    <div className="shell">
      <Sidebar section={section} onNavigate={setSection} open={menuOpen} onClose={() => setMenuOpen(false)} />
      <div className="main">
        <Topbar title={title} subtitle={subtitle} onMenuToggle={() => setMenuOpen((o) => !o)} />
        <div className="content">
          {section === "overview" ? <Overview onNavigate={setSection} /> : <EntitySection section={section} />}
        </div>
      </div>
    </div>
  );
}

export default function AdminApp() {
  return (
    <div className="admin-scope">
      <AuthProvider>
        <ToastProvider>
          <AdminShell />
        </ToastProvider>
      </AuthProvider>
    </div>
  );
}
